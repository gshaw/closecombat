These simple programs convert Close Combat 2 textures to tga files and tga files into CC2 textures.

Copy all the textures from the cd into a folder, run the totga batch file to convert all the textures to tga files.  Make your changes use your paint program and save the files as tga files.  When you want to use them in the game run the fromtga batch file.

Here is the format of the cc2 texture file.

Have fun.


TinTin
gerry_shaw@yahoo.com


typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   DWORD;

// ===========================================================================
// EXAMPLE TEXTURE DATA
//
// 00000: 74787466 00010000 00000027 00000057  txtf.......'...W
// 00010: 39a339a3 39a339a3 39a339a3 39a37fff  9#9#9#9#9#9#9#..
// 00020: 7fff7fff 7fff7fff 7fff7fff 7fff7fff  ................
// 00030: 7fff7fff 7fff7fff 7fff7fff 7fff7fff  ................


typedef struct
{
    DWORD   Signature;              // CC_TEXTUREFILE_HEADER_SIGNATURE
    DWORD   Version;                // CC_TEXTUREFILE_HEADER_VERSION
    DWORD   Width;                  // Width
    DWORD   Height;                 // Height
    WORD*   pBitmapData;            // 16 bpp pixel data (555) (width x height x 2 bytes long)
} TEXTURE;

#define CC_TEXTUREFILE_HEADER_SIGNATURE (DWORD)0x66747874    //  txtf
#define CC_TEXTUREFILE_HEADER_VERSION   (DWORD)0x00000100
