import java.io.*;

/**
 * DOES NOT SUPPORT 8 BIT AT THIS TIME
 */
public class TgaReader { 
	public TgaReader(String name) throws IOException {

		// create output file
		RandomAccessFile f = new RandomAccessFile(name, "r");
		
		// read interesting parts of the header
		f.seek(12);
		width  = readIntelShort(f);
		height = readIntelShort(f);
		
		f.seek(16);
		bpp    = f.readByte();

		final long bufferSize = width*height*bpp/8;
		buffer = new byte[(int)bufferSize];
		f.read(buffer);
		f.close();
	}
	
	public short getWidth() {
		return width;
	}
	
	public short getHeight() {
		return height;
	}

	public byte getBpp() {
		return bpp;
	}

	public byte[] getPixelData() {
		return buffer;
	}
	
	private byte  bpp;
	private short width;
	private short height;
	private byte[] buffer;
	
	private short readIntelShort(RandomAccessFile f) throws IOException {
		short value = (short)(f.read() | f.read() << 8);
		return value;
	}
	
}
