import java.io.*;

/**
 * DOES NOT SUPPORT 8 BIT AT THIS TIME
 */
public class TgaWriter { 
	public TgaWriter(String name, short width, short height, byte bpp, byte[] pixels) throws IOException {

		// delete any existing file (we want to totaly overwrite files
		new File(name).delete();
		
		// create output file
		f = new RandomAccessFile(name, "rw");
		
		// write a TGA header
		f.writeByte(0);				// size of ID field that follows 18 byte header (0 usually)
		f.writeByte(0);				// type of colour map 0=none, 1=has palette
		f.writeByte(2);				// type of image 0=none,1=indexed,2=rgb,3=grey,+8=rle packed
				
		writeIntelShort((short)0);	// first colour map entry in palette
		writeIntelShort((short)0);	// number of colours in palette
		f.writeByte(0);				// number of bits per palette entry 15,16,24,32
				
		writeIntelShort((short)0);	// image x origin
		writeIntelShort((short)0);	// image y origin
		writeIntelShort(width);		// image width in pixels
		writeIntelShort(height);	// image height in pixels
		f.writeByte(bpp);			// image bpp
		f.writeByte(0);				// image descriptor bits (vh flip bits)

		// write pixel data for image
		f.write(pixels);
	}
	
	public void finalize() throws IllegalStateException {
		// ensure that close gets called
		if (f != null) 
			throw new IllegalStateException("TgaWriter must call close method before destroying");
	}
	
	public void setOrigin(short x, short y) throws IOException {
		f.seek(8);				// seek to where image origin is at in file header
		f.writeShort(x);		// image x origin
		f.writeShort(y);		// image y origin
	}
	
	public void close() throws IOException {
		f.close();
		f = null;
	}
	
	private RandomAccessFile f = null;
	
	private void writeIntelShort(short value) throws IOException {
		f.write( value      & 0xff);
		f.write((value>>8)  & 0xff);
	}
}
