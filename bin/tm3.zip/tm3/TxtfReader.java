import java.io.*;

/**
 * This class can be used to read a CC3 vehicle graphic file.
 */
public class TxtfReader { 
	
	/**
	 * Determines if the specified filename is a valid vehicle graphic file file.
	 */
	public static boolean isValidFile(String name) {
		// check to see if the last part of the string ends in a valid extension
		
		if (name.toLowerCase().endsWith(".bgm"))
			return true;
		if (name.toLowerCase().endsWith(".ovm"))
			return true;
		if (name.toLowerCase().endsWith(".mmm"))
			return true;
		
		// if first 4 bytes are 'txtf'
			return true;
		
		//return false;
	}

	public TxtfReader(String name) throws IOException {
		// create new File object for accessing the zfx file
		f = new RandomAccessFile(name, "r");
	}

	/**
	 * Closes the file.
	 */
	public void close() throws IOException {
		f.close();
		f = null;
	}
	
	public int getWidth(int i) throws IOException {
		//f.seek(SIZE_TABLE_OFFSET + i*8);
		return readIntelInt();
	}
	
	public int getHeight(int i) throws IOException {
		//f.seek(SIZE_TABLE_OFFSET + i*8 + 4);
		return readIntelInt();
	}
	
	public byte[] getImageBuffer(int i) throws IOException {
		final int w = getWidth(i);
		final int h = getHeight(i);
		
		//f.seek(offset + IMAGE_DATA_OFFSET);
		byte[] buffer = new byte[w*h*2];
		f.read(buffer);
		
		return buffer;
	}
	
	/** File currently reading from */
	private RandomAccessFile f;
	
	private int readIntelInt() throws IOException {
		int i = f.read() | f.read() << 8 | f.read() << 16 | f.read() << 24;
		return i;
	}
	
	
}


