import java.io.*;
import java.text.*;
import java.math.*;

public class Txtf { 

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main (String[] args) {

		try {
			if (args.length == 1) {
				viewContents(args[0]);
			}
			else if ((args[0].compareTo("-tga") == 0)) {
				convertToTGA(args[1]);
			} 
			else if ((args[0].compareTo("-txtf") == 0)) {
				convertToTxtf(args[1]);
			}
			else {
				printUsage();
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			printUsage();
		}
	}
	
	public static void printUsage() {
		System.out.println("txtf - CC3 Texture Conversion Tool");
		System.out.println("http://members.xoom.com/CloseCombat");
		System.out.println("");
		System.out.println("usage: txtf [(-tga)|(-txtf)] filename");
	}
	
	public static void viewContents(String name) {
	}
	
	public static void convertToTGA(String name) {
	}
	
	public static void convertToTxtf(String name) {
	}
}
