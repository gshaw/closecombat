send comments to icq# 3492098

Close Combat Map Editor

This program only edits the text map files.  It is designed to work with a paint program to edit the graphics.

To edit a map open the map data file or create a new map.

Export the graphics and edit them with your paint program.

Import the graphics back and edit the tile data and elevation.

Save the file (only saves the map data).

Wait for me to finish a tool to create the map graphics (or hack them your self).

Wait for me to finish a los tool (1-2 weeks away).  Or don't worry about it and have the AI play very poor.


Please report any problems - not feature requests.  Post feature requests to the gamestats editor forum.

There will be a minor update in the near feature that will allow editing the tile colors.  Right now they are hardcoded.

Because I have not found a way to run modify maps on NT this program might not even work, please let me know if the saved data works.

Please be patient with me, this is my first real attempt at creating a game addon.


Left mouse button paints with selected tile or elevation.
Right mouse button lifts the tile and makes it the current tile you paint with.

Tile colors are stored in a file called tilecolor.bin, if somebody comes up with a decent color scheme for tiles send it to me and I'll post it here.

Hold down space bar to get a hand scroller, very handy for moving around the map quickly.

TinTin
gerry_shaw@yahoo.com
